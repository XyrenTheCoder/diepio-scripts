window.frozenHasFocus = Object.freeze({
    hasFocus: document.hasFocus
});