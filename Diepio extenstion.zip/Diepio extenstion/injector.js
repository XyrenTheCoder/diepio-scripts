let firstScriptRemoved = false;

// Create a MutationObserver to detect script elements being added to the DOM
const observer = new MutationObserver(function (mutationsList) {
  if (firstScriptRemoved) return;

  for (const mutation of mutationsList) {
    if (mutation.type === 'childList') {
      for (const node of mutation.addedNodes) {
        if (node.tagName === 'SCRIPT' && !node.src) {
          console.log('First inline script detected, removing:', node.innerHTML);
          node.remove();
          firstScriptRemoved = true;
          observer.disconnect(); // Stop observing after first match
          return;
        }
      }
    }
  }
});

// Start observing the entire document
observer.observe(document, {
  childList: true,
  subtree: true
});

// Optional: Immediately check for any inline scripts already in the DOM
const existingScripts = document.querySelectorAll('script:not([src])');
if (existingScripts.length > 0) {
  console.log('First inline script found immediately, removing:', existingScripts[0].innerHTML);
  existingScripts[0].remove();
  firstScriptRemoved = true;
  observer.disconnect();
}

const script = document.createElement('script');
script.src = chrome.runtime.getURL('script.js');
script.type = 'text/javascript';
script.onload = function () {
  this.remove(); // Clean up after execution if you want
};
(document.head || document.documentElement).appendChild(script);

